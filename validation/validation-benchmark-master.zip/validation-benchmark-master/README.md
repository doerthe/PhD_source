# Validation Benchmark

## Usage
- download the datasets (see `dataset-downloader/README.md`)
- run a benchmark of your choice (see `validation-reasoning-framework/README/md` and `rdfunit/README.md`)

## License
MIT
