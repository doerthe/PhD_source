# Benchmark Script for RDFUnit

## Requirements
- docker image of [RDFUnit](https://github.com/AKSW/RDFUnit/wiki/CLI)

## Usage
Execute `run.sh`. To set which datasets need to be considered, update the two for-loops in the script.
