# Dataset Downloader

## Usage
An example command is `node index.js 10 dcterms output 3`. This will download 3 datasets that use the DCTerms ontology and have 10 triples (with 10% deviation).
The datasets will be downloaded to `output/10/dcterms`.

## Schemas
The available schemas can be found in `config.json`.
